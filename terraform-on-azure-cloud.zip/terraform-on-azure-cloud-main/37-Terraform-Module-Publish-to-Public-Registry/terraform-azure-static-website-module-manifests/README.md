# Azure Static Website using Storage Account
- This module provisions Azure Storage Account for static website hosting.
- This is just for Terraform Demo's
- Version: 1.0.0


